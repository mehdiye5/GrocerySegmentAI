package com.sfu.object;

public class StatusResponse {
	public String id;
	public String status;

}
