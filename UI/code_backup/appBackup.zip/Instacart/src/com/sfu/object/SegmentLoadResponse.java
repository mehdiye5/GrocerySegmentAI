package com.sfu.object;

public class SegmentLoadResponse {
	public String id;
	//public String createdAt;
	public String productId;
	
	
	@Override
	public String toString() {
		return "SegmentLoadResponse [id=" + id + ", productId=" + productId + "]";
	}
	
	

}
